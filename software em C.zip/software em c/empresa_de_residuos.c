#include <stdio.h>
#include <string.h>
#include <conio.h> /*PARA OCULTA��O DE SENHAS*/
#include <locale.h>


struct Login {
    char username[20];
    char password[20];
};

void acessoFuncionario(struct Login logins[], int size);
void cadastrarFuncionario();
void lerSenha(char *senha, int tamanhoMax);
void menuOpcoes();
void limparTela();
void cadastrarEmpresa();
void consultarEmpresas();
void opcaoGerenciamento();
void gerenciamentoGlobal();
void gerenciamentoEmpresa();
void visualizarRelatorio();

int main() {
    struct Login logins[2] = {
        /*{"UNIP", "UNIP2024"}*/
    };

    acessoFuncionario(logins, 2);

    return 0;
}
/*Fun��o para realizar o login de um funcion�rio*/
void acessoFuncionario(struct Login logins[], int size) {
    char username[20];
    char password[20];
    int loginSuccess = 0;
    int i;

    printf("Nome de usuario: ");
    scanf("%s", username);

    printf("Senha: ");
    lerSenha(password, 20);
    printf("\n");

FILE *arquivo = fopen("usuarios.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo de usu�rios.\n");
        return;
    }

    struct Login loginAtual;
    while (fscanf(arquivo, "%s %s", loginAtual.username, loginAtual.password) != EOF) {
        if (strcmp(username, loginAtual.username) == 0 && strcmp(password, loginAtual.password) == 0) {
            loginSuccess = 1;
            break;
        }
    }

    fclose(arquivo);

    if (loginSuccess) {
        printf("Login bem-sucedido!\n");
        limparTela();
        menuOpcoes();
    } else {
        printf("Nome de usu�rio ou senha incorretos.\n");
    }
}
/*Fun��o que realiza o cadastro de um novo funcion�rio*/
void cadastrarFuncionario() {
    struct Login novoLogin;
    printf("Digite o nome de usu�rio: ");
    scanf("%s", novoLogin.username);

    printf("Digite a senha: ");
    lerSenha(novoLogin.password, 20);
    printf("\n");

    /* Salvar no arquivo*/
    FILE *arquivo = fopen("usuarios.txt", "a");
    if (arquivo != NULL) {
    fprintf(arquivo, "%s %s\n", novoLogin.username, novoLogin.password);
    fclose(arquivo);
    printf("Novo funcionario cadastrado com sucesso!\n");

} else {
    printf("Erro ao abrir o arquivo para escrita.\n");
}}
/*mascara a entrada de senha ao digitar*/
void lerSenha(char *senha, int tamanhoMax) {
    int i = 0;
    char ch;

    while (1) {
        ch = getch();

        if (ch == 13) {
            senha[i] = '\0';
            break;
        } else if (ch == 8) {
            if (i > 0) {
                i--;
                printf("\b \b");
            }
        } else if (i < tamanhoMax - 1) {
            senha[i] = ch;
            i++;
            printf("*");
        }
    }
}

/*tela de menu*/
void menuOpcoes() {
    int opcao;

    do {

        printf("\n--- Menu de Opcoes ---\n");
        printf("1. Cadastrar Empresa\n");
        printf("2. Consultar Empresa\n");
        printf("3. Visualizar Relatorios Residuais\n");
        printf("4. Gerenciamento\n");
        printf("5. Cadastrar Funcionario\n");
        printf("0. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        limparTela();

        switch(opcao) {
            case 1:
                cadastrarEmpresa();
                break;
            case 2:
                consultarEmpresas();
                break;
            case 3:
                visualizarRelatorio();
                break;
            case 4:
                opcaoGerenciamento();
                break;
            case 5:
                cadastrarFuncionario();
                break;
            case 0:
                printf("Saindo...\n");
                break;
                    }
    } while(opcao != 0);
}

void mascararCPF(char cpf[]) {
    int i;
    for ( i = 3; i < 9; i++) {
        cpf[i] = '*';
    }
}

void mascararCNPJ(char cnpj[]) {
    int i;
    for ( i = 2; i < 8; i++) {
        cnpj[i] = '*';
    }
}

/*Cadastramento de empresa*/
void cadastrarEmpresa() {
    char nomeEmpresa[100];
    char cnpj[15], razaoSocial[100], nomeFantasia[200], email[100], dataAbertura[11];
    char endereco[200], telefone[15], nomeResponsavel[100], dataNascimento[11], cpfResponsavel[12], emailResponsavel[100], contatoResponsavel[12];
    FILE *arquivo;

    printf("Digite o nome da empresa: ");
    scanf(" %99[^\n]", nomeEmpresa);
    printf("Digite o CNPJ (apenas numeros): ");
    scanf(" %14[^\n]", cnpj);
    printf("Digite a razao social: ");
    scanf(" %99[^\n]", razaoSocial);
    printf("Digite o nome fantasia: ");
    scanf(" %99[^\n]", nomeFantasia);
    printf("Digite o e-mail da empresa: ");
    scanf(" %99[^\n]", email);
    printf("Digite a data de abertura (dd/mm/aaaa): ");
    scanf(" %10[^\n]", dataAbertura);
    printf("Digite o endere�o (CEP, rua, bairro, cidade, estado e numero): ");
    scanf(" %199[^\n]", endereco);
    printf("Digite o telefone da empresa: ");
    scanf(" %14[^\n]", telefone);
    printf("Digite o nome do responsavel: ");
    scanf(" %99[^\n]", nomeResponsavel);
    printf("Digite a data de nascimento (dd/mm/aaaa): ");
    scanf(" %10[^\n]", dataNascimento);
    printf("Digite o CPF do responsavel (apenas numeros): ");
    scanf(" %11[^\n]", cpfResponsavel);
    printf("Digite o e-mail do responsavel: ");
    scanf(" %99[^\n]", emailResponsavel);
    printf("Digite contato do responsavel: ");
    scanf(" %11[^\n]", contatoResponsavel);

        /* Mascarar CPF e CNPJ antes de salvar */
    char cpfMascarado[15], cnpjMascarado[15];
    strcpy(cpfMascarado, cpfResponsavel);
    strcpy(cnpjMascarado, cnpj);
    mascararCPF(cpfMascarado);
    mascararCNPJ(cnpjMascarado);

    char nomeArquivo[205]; /* Para armazenar o nome do arquivo */
int st = snprintf(nomeArquivo, sizeof(nomeArquivo), "empresas cadastradas\\%s.txt", nomeFantasia);
if (st < 0 || st >= sizeof(nomeArquivo)) {
    printf("Erro ao formatar o nome do arquivo.\n");
    return;
}
    /* Abre o arquivo para escrita*/
    arquivo = fopen(nomeArquivo, "w");
    if (arquivo == NULL) {
        perror("Erro ao criar o arquivo.\n");
        return;
    }

    /*Escreve os dados no arquivo*/
    fprintf(arquivo, "Nome da Empresa: %s\n", nomeEmpresa);
    fprintf(arquivo, "CNPJ: %s\n", cnpjMascarado);
    fprintf(arquivo, "Raz�o Social: %s\n", razaoSocial);
    fprintf(arquivo, "Nome Fantasia: %s\n", nomeFantasia);
    fprintf(arquivo, "E-mail: %s\n", email);
    fprintf(arquivo, "Data de Abertura: %s\n", dataAbertura);
    fprintf(arquivo, "Endere�o: %s\n", endereco);
    fprintf(arquivo, "Telefone: %s\n", telefone);
    fprintf(arquivo, "Nome do Respons�vel: %s\n", nomeResponsavel);
    fprintf(arquivo, "Data de Nascimento: %s\n", dataNascimento);
    fprintf(arquivo, "CPF do Respons�vel: %s\n", cpfMascarado);
    fprintf(arquivo, "E-mail do Respons�vel: %s\n", emailResponsavel);
    fprintf(arquivo, "Contato do Respons�vel: %s\n", contatoResponsavel);

    /*Fecha o arquivo*/
    fclose(arquivo);

    printf("Empresa cadastrada com sucesso e dados salvos em %s\n", nomeArquivo);

    printf("\nPressione Enter para continuar...");
    getchar();
    getchar();

}
/*consulta da empresa ja cadastrada*/
void consultarEmpresas() {
   char nomeFantasia[100], cnpj[15], cpfResponsavel[12];  /*Arrays com tamanhos adequados*/
    FILE *arquivo;
    char nomeArquivo[200];

    /* Solicita o nome da empresa ao usu�rio*/
    printf("Digite o nome fantasia da empresa que deseja consultar: ");
    scanf(" %99[^\n]", nomeFantasia);  /* Captura o nome fantasia*/
    getchar();  /* Limpa o buffer do teclado*/

    /* Monta o nome do arquivo a ser lido*/
    sprintf(nomeArquivo, "empresas cadastradas/%s.txt", nomeFantasia);

    /* Tenta abrir o arquivo da empresa*/
    arquivo = fopen(nomeArquivo, "r");
    if (arquivo == NULL) {
        printf("Empresa nao encontrada.\n");
        return;
    }

    char linha[200];

    /* L� e exibe os dados da empresa*/
    printf("\n--- Dados da Empresa ---\n");
    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        /* Se for linha contendo o CNPJ, ele ser� lido e mascarado*/
        if (strstr(linha, "CNPJ:") != NULL) {
            sscanf(linha, "CNPJ: %14s", cnpj);
            mascararCNPJ(cnpj);
            printf("CNPJ: %s\n", cnpj);
        }
        /* Se for linha contendo o CPF do respons�vel, ele ser� lido e mascarado*/
        else if (strstr(linha, "CPF do Respons�vel:") != NULL) {
            sscanf(linha, "CPF do Respons�vel: %11s", cpfResponsavel);
            mascararCPF(cpfResponsavel);
            printf("CPF do Respons�vel: %s\n", cpfResponsavel);
        } else {
            /* Exibe as demais linhas sem altera��o*/
            printf("%s", linha);
        }
}    fclose(arquivo);

    printf("\nPressione Enter para voltar ao menu...");
    getchar();

    system("cls");
}


/*que tipo de gerenciamneto o usuario ia realizar*/
void opcaoGerenciamento(){
    int opcoes;
    printf("\n--- Menu de Opcoes ---\n");
    printf("1. GLOBAL\n");
    printf("2. POR EMPRESA\n");
    printf("0. Sair\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcoes);

    switch(opcoes) {
        case 1:
            gerenciamentoGlobal();
            break;
        case 2:
            gerenciamentoEmpresa();
            break;
        case 0:
            printf("Saindo....\n");
            break;
    }
}
/*insers�o de dados globais*/
void gerenciamentoGlobal() {
    char regioesVolumeAlto[50];
    char industriasMenorProd[100]; /*qual setor*/
    char financeiroSemestral[100];

    printf("Digite quais regioes com maior volume de residuos industriais tratados: ");
    scanf(" %[^\n]", regioesVolumeAlto);
    printf("Digite quais industrias com menor producao no ultimo semestre: ");
    scanf(" %[^\n]", industriasMenorProd);
    printf("Digite qual foi o aporte financeiro semestral: ");
    scanf(" %[^\n]", financeiroSemestral);

    FILE *arquivo;

    char nomeArquivo[105]; /*Para armazenar o nome do arquivo*/
    snprintf(nomeArquivo, sizeof(nomeArquivo), "gerenciamento de residuos GLOBAL/%s.txt", regioesVolumeAlto);

    arquivo = fopen(nomeArquivo, "a"); /*Modo "a" para abrir em modo de append (adicionar)*/
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo.\n");
        return;
    }

    fseek(arquivo, 0, SEEK_END);
    if (ftell(arquivo) == 0) {
        fprintf(arquivo, "Regi�es com maior volume de res�duos industriais tratados: %s\n", regioesVolumeAlto);
        fprintf(arquivo, "Ind�strias com menor produ��o no �ltimo semestre: %s\n", industriasMenorProd);
        fprintf(arquivo, "Aporte financeiro semestral: %s\n", financeiroSemestral);
    } else {
        fprintf(arquivo, "\nRegi�es com maior volume de res�duos industriais tratados: %s\n", regioesVolumeAlto);
        fprintf(arquivo, "Ind�strias com menor produ��o no �ltimo semestre: %s\n", industriasMenorProd);
        fprintf(arquivo, "Aporte financeiro semestral: %s\n", financeiroSemestral);
    }

    fclose(arquivo);
    printf("Dados atualizados com sucesso e dados salvos em %s\n", nomeArquivo);

    int opcaoDownload;
    printf("Deseja baixar uma copia dos dados em:\n");
    printf("1. Formato TXT\n");
    printf("2. Formato CSV\n");
    printf("0. Nao baixar\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcaoDownload);

    if (opcaoDownload == 1 || opcaoDownload == 2) {
        printf("Digite o caminho completo onde deseja salvar o arquivo (ex: C:/Meus Documentos/arquivo): ");
        getchar(); /* Limpa o buffer de entrada */
        fgets(nomeArquivo, sizeof(nomeArquivo), stdin);
        nomeArquivo[strcspn(nomeArquivo, "\n")] = 0; /* Remove o caractere de nova linha */

        if (opcaoDownload == 1) {
            snprintf(nomeArquivo, sizeof(nomeArquivo), "%s\\%s_download.txt", nomeArquivo, regioesVolumeAlto);
            arquivo = fopen(nomeArquivo, "a"); /* Modo "a" para adicionar sem sobrescrever */
            if (arquivo == NULL) {
                printf("Erro ao criar o arquivo de download.\n");
                return;
            }

            fseek(arquivo, 0, SEEK_END);
            if (ftell(arquivo) == 0) {
                fprintf(arquivo, "Regi�es com maior volume de res�duos industriais tratados: %s\n", regioesVolumeAlto);
                fprintf(arquivo, "Ind�strias com menor produ��o no �ltimo semestre: %s\n", industriasMenorProd);
                fprintf(arquivo, "Aporte financeiro semestral: %s\n", financeiroSemestral);
            } else {
                fprintf(arquivo, "\nRegi�es com maior volume de res�duos industriais tratados: %s\n", regioesVolumeAlto);
                fprintf(arquivo, "Ind�strias com menor produ��o no �ltimo semestre: %s\n", industriasMenorProd);
                fprintf(arquivo, "Aporte financeiro semestral: %s\n", financeiroSemestral);
            }

            fclose(arquivo);
            printf("C�pia em TXT salva em %s\n", nomeArquivo);
        } else if (opcaoDownload == 2) {
            snprintf(nomeArquivo, sizeof(nomeArquivo), "%s\\%s_download.csv", nomeArquivo, regioesVolumeAlto);
            arquivo = fopen(nomeArquivo, "a"); /* Modo "a" para adicionar sem sobrescrever */
            if (arquivo == NULL) {
                printf("Erro ao criar o arquivo de download.\n");
                return;
            }

            fseek(arquivo, 0, SEEK_END);
            if (ftell(arquivo) == 0) {
                fprintf(arquivo, "Regi�es com maior volume de res�duos industriais tratados;Ind�strias com menor produ��o no �ltimo semestre;Aporte financeiro semestral\n");
            }

            fprintf(arquivo, "%s;%s;%s\n", regioesVolumeAlto, industriasMenorProd, financeiroSemestral);

            fclose(arquivo);
            printf("C�pia em CSV salva em %s\n", nomeArquivo);
        }
    }
}
/*insers�o de dados de cada empresa*/
void gerenciamentoEmpresa() {
    char dataNovosDados[100];
    char atualizacaoDaEmpresa[100];
    char QntResiduos[100];
    char QntResiduosTratados[100];
    char valorCusto[100];

    printf("Digite a data que esta atualizando os dados (dd/mm/aaaa): ");
    scanf(" %[^\n]", dataNovosDados);
    printf("Digite o nome da empresa que esta atualizando os dados: ");
    scanf(" %[^\n]", atualizacaoDaEmpresa);
    printf("Digite a quantidade total de residuos industriais da empresa: ");
    scanf(" %[^\n]", QntResiduos);
    printf("Digite a quantidade de residuos industriais que foram tratados no periodo (em porcentagem): ");
    scanf(" %[^\n]", QntResiduosTratados);
    printf("Digite o custo total: ");
    scanf(" %[^\n]", valorCusto);

    FILE *arquivo;

    char nomeArquivo[105]; /*Para armazenar o nome do arquivo*/
    snprintf(nomeArquivo, sizeof(nomeArquivo), "gerenciamento de residuos POR EMPRESA/%s.txt", atualizacaoDaEmpresa);

    arquivo = fopen(nomeArquivo, "a");
    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo.\n");
        return;
    }

    fprintf(arquivo, "Data da atualiza��o: %s\n", dataNovosDados);
    fprintf(arquivo, "Empresa: %s\n", atualizacaoDaEmpresa);
    fprintf(arquivo, "Quantidade total de residuos industriais: %s\n", QntResiduos);
    fprintf(arquivo, "Quantidade de residuos industriais tratados no periodo: %s\n", QntResiduosTratados);
    fprintf(arquivo, "Custo total: %s\n", valorCusto);

    fclose(arquivo);
    printf("Dados atualizados com sucesso e dados salvos em %s\n", nomeArquivo);

    int opcaoDownload;
    printf("Deseja baixar uma copia dos dados em:\n");
    printf("1. Formato TXT\n");
    printf("2. Formato CSV\n");
    printf("0. Nao baixar\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcaoDownload);

  if (opcaoDownload == 1 || opcaoDownload == 2) {
        printf("Digite o caminho completo onde deseja salvar o arquivo (ex: C:/Meus Documentos/arquivo): ");
        getchar();
        fgets(nomeArquivo, sizeof(nomeArquivo), stdin);
        nomeArquivo[strcspn(nomeArquivo, "\n")] = 0;

        if (opcaoDownload == 1) {
            snprintf(nomeArquivo, sizeof(nomeArquivo), "%s\\%s_download.txt", nomeArquivo, atualizacaoDaEmpresa);
            FILE *arquivo = fopen(nomeArquivo, "a");
            if (arquivo == NULL) {
                printf("Erro ao criar o arquivo de download.\n");
                return;
            }
            fprintf(arquivo, "Data da atualiza��o: %s\n", dataNovosDados);
            fprintf(arquivo, "Nome da Empresa que atualizou: %s\n", atualizacaoDaEmpresa);
            fprintf(arquivo, "Quantidade de res�duos: %s\n", QntResiduos);
            fprintf(arquivo, "Quantidade de res�duos TRATADOS: %s\n", QntResiduosTratados);
            fprintf(arquivo, "Valor estimado de custos: %s\n", valorCusto);
            fclose(arquivo);
            printf("C�pia em TXT salva em %s\n", nomeArquivo);
        } else if (opcaoDownload == 2) {
            snprintf(nomeArquivo, sizeof(nomeArquivo), "%s\\%s_download.csv", nomeArquivo, atualizacaoDaEmpresa);
            FILE *arquivo = fopen(nomeArquivo, "a");
            if (arquivo == NULL) {
                printf("Erro ao criar o arquivo de download.\n");
                return;
            }
           if (ftell(arquivo) == 0) {
                fprintf(arquivo, "Data da atualiza��o;Nome da Empresa;Quantidade de res�duos;Quantidade de res�duos TRATADOS;Valor estimado de custos\n");
            }
            fprintf(arquivo, "%s;%s;%s;%s;%s\n", dataNovosDados, atualizacaoDaEmpresa, QntResiduos, QntResiduosTratados, valorCusto);

            fclose(arquivo);
            printf("C�pia em CSV salva em %s\n", nomeArquivo);
        }
    } else {
        printf("Nenhuma c�pia baixada.\n");


    limparTela();
}
}
/*vizualiza��o dos dos gerenciamentos*/
void visualizarRelatorio(){
     int opcoes;
    char regiao[100];
    char nomeFantasia[100];
    char caminhoArquivo[200];
    char linha[200];
    char Empresa[200];
    FILE *arquivo;
    printf("\n--- Visualizar ---\n");
    printf("1. Consultar por Regiao\n");
    printf("2. Consultar por Empresa\n");
    printf("0. Sair\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcoes);
    switch(opcoes) {
        case 1:
            printf("Digite o nome da regiao: ");
            scanf(" %99[^\n]", regiao);
            getchar();

            snprintf(caminhoArquivo, sizeof(caminhoArquivo),
                "gerenciamento de residuos GLOBAL\\%s.txt",
                regiao);

            arquivo = fopen(caminhoArquivo, "r");
            if (arquivo == NULL) {
                printf("Relatorio da regiao '%s' nao encontrado.\n", regiao);
                return;
            }

            printf("\n--- Relatorio da Regiao: %s ---\n", regiao);
            while (fgets(linha, sizeof(linha), arquivo) != NULL) {
                printf("%s", linha);
            }
            fclose(arquivo);
            printf("\nPressione Enter para continuar...");
            getchar();
            break;
        case 2:
            printf("Digite o nome da Empresa: ");
            scanf(" %99[^\n]", Empresa);
            getchar();

            snprintf(caminhoArquivo, sizeof(caminhoArquivo),
                "gerenciamento de residuos POR EMPRESA\\%s.txt",
                Empresa);

            arquivo = fopen(caminhoArquivo, "r");
            if (arquivo == NULL) {
                printf("Relatorio da Empresa '%s' nao encontrado.\n", Empresa);
                return;
            }

            printf("\n--- Relatorio da Empresa: %s ---\n", Empresa);
            while (fgets(linha, sizeof(linha), arquivo) != NULL) {
                printf("%s", linha);
            }
            fclose(arquivo);
            printf("\nPressione Enter para continuar...");
            getchar();
            break;
        case 0:
            printf("Saindo....\n");
            break;
} }



void limparTela() {
    system("cls");
}

